<?php return array (
  'autos-index' => 'App\\Http\\Livewire\\AutosIndex',
  'clientes-index' => 'App\\Http\\Livewire\\ClientesIndex',
);