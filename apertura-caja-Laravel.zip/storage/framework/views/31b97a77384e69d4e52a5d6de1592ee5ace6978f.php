

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">PANEL DE CONTROL DE USUARIOS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header d-flex justify-content-start align-items-center">
                <h3 class="card-title mr-3">Usuarios</h3>
                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success mr-2"><i
                        class="far fa-plus-square mr-1"></i>Crear</a>

            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th class="col-2">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($usuario->name); ?></td>
                                <td><?php echo e($usuario->email); ?></td>
                                <td>
                                    <div class="row mx-auto">
                                        <a href="<?php echo e(route('users.edit', $usuario)); ?>" class="btn btn-primary mr-2"><i
                                                class="fas fa-edit"></i></a>
                                        <a href="<?php echo e(route('password',$usuario)); ?>" class="btn btn-warning mr-2"><i
                                                class="fas fa-lock text-white"></i></a>

                                        <form action="<?php echo e(route('users.destroy', $usuario)); ?>" method="POST"
                                            class="formulario-eliminar">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit" class="btn btn-danger">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">
                <?php echo e($usuarios->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <?php if(session('Creado')): ?>
        <script>
            Swal.fire(
                'Creado!',
                '<?php echo e(session('Creado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Actualizado')): ?>
        <script>
            Swal.fire(
                'Actualizado!',
                '<?php echo e(session('Actualizado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Borrado')): ?>
        <script>
            Swal.fire(
                'Borrado!',
                '<?php echo e(session('Borrado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>


    <?php if(session('Error')): ?>
        <script>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo e(session('Error')); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            })
        </script>
    <?php endif; ?>


    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Estas seguro?',
                text: "No podras revertir esto.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Borrar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    /* Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    ) */

                    this.submit();
                }

            })

        });
    </script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/admin/users/index.blade.php ENDPATH**/ ?>