

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="container my-4">    
</div>


<div class="container mt-2 ">
    <div class="container mx-auto">
        <div class="card shadow">
            <div class="card-header">
              <h3 class="card-title">
                Información del cliente <?php echo e($cliente->nombre); ?>

              </h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <dl>
                <dt>Nombre</dt>
                <dd><?php echo e($cliente->nombre); ?></dd>
                <dt>Celular</dt>
                <dd><?php echo e($cliente->celular); ?></dd>
                <dt>Email</dt>
                <dd><?php echo e($cliente->email); ?></dd>
                <dt>Ciudad</dt>
                <dd><?php echo e($cliente->ciudad); ?></dd>
                <dt>Provincia</dt>
                <dd><?php echo e($cliente->provincia); ?></dd>
                
                <dt>Nota</dt>
                <dd><?php echo e($cliente->nota); ?></dd>
                <dt>Estado</dt>
                <?php switch( $cliente->estado ):
                                case ('compra'): ?>
                                    <small class="badge badge-warning text-white"> compra</small>
                                    <?php break; ?>
                                <?php case ('venta'): ?>
                                    <small class="badge badge-primary"> venta</small>
                                    <?php break; ?>
                                <?php case ('compra-venta'): ?>
                                    <small class="badge badge-success"> compra-venta</small>
                                    <?php break; ?>
                                <?php default: ?>
                                    
                <?php endswitch; ?>
              </dl>
            </div>
            <!-- /.card-body -->
        </div>

        
        <div class="mx-auto">
            <div class="row mx-auto mt-3">
                 <a href="<?php echo e(route('clientes.index' )); ?>" class="btn btn-secondary mr-2 shadow">Volver</a>
            </div>
        </div>
    </div>
    
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/admin/clientes/show.blade.php ENDPATH**/ ?>