<div class="table-responsive">
    <input class="form-control mb-3" wire:model="search" type="search" placeholder="Buscar...">

    <table class="table table-bordered ">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Condición</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Versión</th>
                <th>Año</th>
                <th>Precio</th>
                <th>Ciudad</th>
                <th>Provincia</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(date('d-m-Y', strtotime($auto->created_at))); ?></td>
                    <td><?php echo e($auto->condicion); ?></td>
                    <td><?php echo e($auto->marca); ?></td>
                    <td><?php echo e($auto->modelo); ?></td>
                    <td><?php echo e($auto->version); ?></td>
                    <td><?php echo e($auto->año); ?></td>
                    <td>$<?php echo e($auto->precio); ?></td>
                    <td><?php echo e($auto->ciudad); ?></td>
                    <td><?php echo e($auto->provincia); ?></td>
                    
                    <td class="">
                        <div class="row mx-auto">
                            <a href="<?php echo e(route('autos.show', $auto)); ?>" class="btn btn-success mr-2"><i
                                    class="far fa-eye"></i></a>
                            <a href="<?php echo e(route('autos.edit', $auto)); ?>" class="btn btn-primary mr-2"><i
                                    class="fas fa-edit"></i></a>

                            <form action="<?php echo e(route('autos.destroy', $auto)); ?>" method="POST"
                                class="formulario-eliminar">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

        </tbody>
    </table>
    <div class="card-footer clearfix">
        <?php echo e($autos->links()); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/livewire/autos-index.blade.php ENDPATH**/ ?>