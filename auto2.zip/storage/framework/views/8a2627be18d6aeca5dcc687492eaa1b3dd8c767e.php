<!DOCTYPE html>

<head>
    <style>
        .customers {
            font-size: 16px;
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            border-spacing: 0;
            width: 50%;
        }


        th{
            text-align: start;
            background-color: lightgrey;
            border:2px solid grey;
            padding: 5px;
        }
        td{
            border: 2px solid grey;
            padding: 5px 10px;
        }
        hr{
            margin: 20px 0;
        }

    </style>


</head>

<body>

    <img src="/storage/<?php echo e($dato->imagen); ?>" alt="">

    <h1><?php echo e($dato->nombre); ?></h1>

    <h3>Dirección: <?php echo e($dato->direccion); ?></h3>
    <h3>Teléfono: <?php echo e($dato->telefonofijo); ?></h3>
    <h3>Whatsapp: <?php echo e($dato->telefonowhatsapp); ?></h3>
    <h3>Email: <?php echo e($dato->email); ?></h3>

    <hr>

    <table class="customers">
        <tbody>
            <tr>
                <th scope="row">Condición:</th>
                <td><?php echo e($auto->condicion); ?></td>
            </tr>
            <tr>
                <th scope="row">Marca:</th>
                <td><?php echo e($auto->marca); ?></td>
            </tr>
            <tr>
                <th scope="row">Modelo</th>
                <td><?php echo e($auto->modelo); ?></td>
            </tr>
            <tr>
                <th scope="row">Versión:</th>
                <td><?php echo e($auto->version); ?></td>
            </tr>
            <tr>
                <th scope="row">Año:</th>
                <td><?php echo e($auto->año); ?></td>
            </tr>
            <tr>
                <th scope="row">Precio:</th>
                <td>$<?php echo e($auto->precio); ?></td>
            </tr>
            <tr>
                <th scope="row">Provincia</th>
                <td><?php echo e($auto->provincia); ?></td>
            </tr>
            <tr>
                <th scope="row">Ciudad</th>
                <td><?php echo e($auto->ciudad); ?></td>
            </tr>
            <tr>
                <th scope="row">Tipo:</th>
                <td><?php echo e($auto->tipo); ?></td>
            </tr>
            <tr>
                <th scope="row">Kilometraje:</th>
                <td><?php echo e($auto->kilometraje); ?></td>
            </tr>
            <tr>
                <th scope="row">Combustible</th>
                <td><?php echo e($auto->combustible); ?></td>
            </tr>
            <tr>
                <th scope="row">Tipo de motor:</th>
                <td><?php echo e($auto->tipomotor); ?></td>
            </tr>
            <tr>
                <th scope="row">Tracción:</th>
                <td><?php echo e($auto->traccion); ?></td>
            </tr>
            <tr>
                <th scope="row">Caja:</th>
                <td><?php echo e($auto->caja); ?></td>
            </tr>
            <tr>
                <th scope="row">Color</th>
                <td><?php echo e($auto->color); ?></td>
            </tr>
            <tr>
                <th scope="row">Tapizado</th>
                <td><?php echo e($auto->tapizado); ?></td>
            </tr>
            <tr>
                <th scope="row">Dirección</th>
                <td><?php echo e($auto->direccion); ?></td>
            </tr>
            <tr>
                <th scope="row">Valor</th>
                <td><?php echo e($auto->valor); ?></td>
            </tr>
            <tr>
                <th scope="row">Permuta</th>
                <td><?php echo e($auto->permuta); ?></td>
            </tr>

        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/admin/autos/pdf.blade.php ENDPATH**/ ?>