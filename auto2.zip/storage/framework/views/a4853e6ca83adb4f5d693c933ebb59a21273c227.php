<div class="table-responsive">
    <input class="form-control mb-3" wire:model="search" type="search" placeholder="Buscar por nombre...">

    <table class="table table-bordered ">
        <thead>
            <tr>

                <th>Nombre</th>
                <th class="col-2">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($modelo->nombre); ?></td>
                    <td class="">
                        <div class="row mx-auto">
                            
                            <a href="<?php echo e(route('modelos.edit', $modelo)); ?>" class="btn btn-primary mr-2"><i
                                    class="fas fa-edit"></i></a>

                            <form action="<?php echo e(route('modelos.destroy', $modelo)); ?>" method="POST"
                                class="formulario-eliminar">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

        </tbody>
    </table>
    <div class="card-footer clearfix">
        <?php echo e($modelos->links()); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/livewire/modelos-index.blade.php ENDPATH**/ ?>