

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">PANEL DE CONTROL DE STOCK DE AUTOS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header d-flex justify-content-start align-items-center">
                <h3 class="card-title mr-3">Autos</h3>
                <a href="<?php echo e(route('autos.create')); ?>" class="btn btn-success mr-2"><i
                        class="far fa-plus-square mr-1"></i>Crear</a>

            </div>
            <!-- /.card-header -->
            <div class="card-body">


                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('autos-index')->html();
} elseif ($_instance->childHasBeenRendered('ddFVL0P')) {
    $componentId = $_instance->getRenderedChildComponentId('ddFVL0P');
    $componentTag = $_instance->getRenderedChildComponentTagName('ddFVL0P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ddFVL0P');
} else {
    $response = \Livewire\Livewire::mount('autos-index');
    $html = $response->html();
    $_instance->logRenderedChild('ddFVL0P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <?php if(session('Creado')): ?>
        <script>
            Swal.fire(
                'Creado!',
                '<?php echo e(session('Creado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Actualizado')): ?>
        <script>
            Swal.fire(
                'Actualizado!',
                '<?php echo e(session('Actualizado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Borrado')): ?>
        <script>
            Swal.fire(
                'Borrado!',
                '<?php echo e(session('Borrado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>


    <?php if(session('Error')): ?>
        <script>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo e(session('Error')); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            })
        </script>
    <?php endif; ?>


    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Estas seguro?',
                text: "No podras revertir esto.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Borrar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    /* Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    ) */

                    this.submit();
                }

            })

        });
    </script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/admin/autos/index.blade.php ENDPATH**/ ?>