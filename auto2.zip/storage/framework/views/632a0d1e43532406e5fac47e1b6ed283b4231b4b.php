

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-center">CONFIGURACIÓN DE DATOS DE EMPRESA</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">


        <div class="card">


            <div class="card-header d-flex justify-content-start align-items-center">


                <?php if(count($datos)): ?>

                <?php $dato =$datos->first();?>

                <a href="<?php echo e(route('datos.edit',$dato)); ?>" class="btn btn-primary mr-2"><i class="fas fa-edit"></i>Editar</a>

                <?php else: ?>
                <a href="<?php echo e(route('datos.create')); ?>" class="btn btn-success mr-2"><i class="far fa-plus-square mr-1"></i>Ingresar datos</a>

                <?php endif; ?>




            </div>
            <!-- /.card-header -->
            <div class="card-body">

                <table class="table">
                    <tbody>
                        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <th scope="row">Nombre:</th>
                                <td><?php echo e($dato->nombre); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Teléfono fino:</th>
                                <td><?php echo e($dato->telefonofijo); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Whatsapp</th>
                                <td><?php echo e($dato->telefonowhatsapp); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Dirección:</th>
                                <td><?php echo e($dato->direccion); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email:</th>
                                <td><?php echo e($dato->email); ?></td>
                            </tr>

                            <tr>
                                <th>Logo:</th>
                                <td><img src="/storage/<?php echo e($dato->imagen); ?>" alt="" class="w-50"></td>

                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <?php if(session('Creado')): ?>
        <script>
            Swal.fire(
                'Éxito!',
                '<?php echo e(session('Creado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Actualizado')): ?>
        <script>
            Swal.fire(
                'Actualizado!',
                '<?php echo e(session('Actualizado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>

    <?php if(session('Borrado')): ?>
        <script>
            Swal.fire(
                'Borrado!',
                '<?php echo e(session('Borrado')); ?>',
                'success'
            )
        </script>
    <?php endif; ?>


    <?php if(session('Error')): ?>
        <script>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo e(session('Error')); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            })
        </script>
    <?php endif; ?>


    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Estas seguro?',
                text: "No podras revertir esto.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Borrar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    /* Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    ) */

                    this.submit();
                }

            })

        });
    </script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/admin/datos/index.blade.php ENDPATH**/ ?>