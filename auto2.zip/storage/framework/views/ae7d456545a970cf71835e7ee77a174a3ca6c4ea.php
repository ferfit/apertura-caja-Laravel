

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container my-4">
    </div>


    <div class="container mt-2 ">
        <div class="container mx-auto">
            <div class="card shadow">
                <div class="card-header">
                    <h3 class="card-title">
                        Información del auto:
                    </h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <dl class="row">
                        <div class="col-6 col-xl-3">
                            <dt>Condición</dt>
                            <dd><?php echo e($auto->condicion); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Marca</dt>
                            <dd><?php echo e($auto->marca); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Modelo</dt>
                            <dd><?php echo e($auto->modelo); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Versión</dt>
                            <dd><?php echo e($auto->version); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Año</dt>
                            <dd><?php echo e($auto->año); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Precio Compra</dt>
                            <dd>$<?php echo e($auto->preciocosto); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Precio Venta</dt>
                            <dd>$<?php echo e($auto->precio); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Ciudad</dt>
                            <dd><?php echo e($auto->ciudad); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Provincia</dt>
                            <dd><?php echo e($auto->provincia); ?></dd>
                        </div>

                    </dl>
                </div>
                <!-- /.card-body -->
            </div>
            <div class="card shadow">

                <!-- /.card-header -->
                <div class="card-body">
                    <dl class="row">
                        <div class="col-6 col-xl-3">
                            <dt>Tipo</dt>
                            <dd><?php echo e($auto->tipo); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Kilometraje</dt>
                            <dd><?php echo e($auto->kilometraje); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Combustible</dt>
                            <dd><?php echo e($auto->combustible); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Tipo de motor</dt>
                            <dd><?php echo e($auto->tipomotor); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Tracción</dt>
                            <dd><?php echo e($auto->traccion); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Caja</dt>
                            <dd><?php echo e($auto->cajaauto); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Color</dt>
                            <dd><?php echo e($auto->color); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Tapizado</dt>
                            <dd><?php echo e($auto->tapizado); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Dirección</dt>
                            <dd><?php echo e($auto->direccion); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Valor</dt>
                            <dd><?php echo e($auto->valor); ?></dd>
                        </div>
                        <div class="col-6 col-xl-3">
                            <dt>Permuta<dt>
                            <dd><?php echo e($auto->Permuta); ?></dd>
                        </div>

                    </dl>
                </div>
                <!-- /.card-body -->
            </div>


            <div class="mx-auto">
                <div class="row mx-auto mt-3">
                    <a href="<?php echo e(route('autos.index')); ?>" class="btn btn-secondary mr-2 shadow">Volver</a>
                    <a href="<?php echo e(route('autoPdf', $auto)); ?>" class="btn btn-primary mr-2 shadow"><i class="fas fa-download mr-1"></i>PDF</a>
                </div>
            </div>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apertura-caja-Laravel\resources\views/admin/autos/show.blade.php ENDPATH**/ ?>