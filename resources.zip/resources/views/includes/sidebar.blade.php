<!-- Sidebar Panel Start -->
<div class="listing_sidebar">
    <div class="siderbar_left_home pt20">
        <a class="sidebar_switch sidebar_close_btn float-end" href="#">X</a>
        <div class="footer_contact_widget mt100">
            <h3 class="title">Quick contact info</h3>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                Aenean massa. Cum sociis Theme natoque penatibus et magnis dis parturient montes, nascetur.</p>
        </div>
        <div class="footer_contact_widget">
            <h5 class="title">CONTACT</h5>
            <div class="footer_phone">+1 670 936 46 70</div>
            <p>hello@voiture.com</p>
        </div>
        <div class="footer_about_widget">
            <h5 class="title">OFFICE</h5>
            <p>Germany —<br>329 Queensberry Street,<br>North Melbourne VIC 3051</p>
        </div>
        <div class="footer_contact_widget">
            <h5 class="title">OPENING HOURS</h5>
            <p>Monday – Friday: 09:00AM – 09:00PM<br>Saturday: 09:00AM – 07:00PM<br>Sunday: Closed</p>
        </div>
    </div>
</div>
<!-- Sidebar Panel End -->
