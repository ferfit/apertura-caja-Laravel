@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1 class="text-center">PANEL DE CONTROL GENERAL</h1>
@stop

@section('content')
    <p class=""></p>
@stop

@section('css')
@stop

@section('js')
@stop