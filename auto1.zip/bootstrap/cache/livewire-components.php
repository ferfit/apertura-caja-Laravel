<?php return array (
  'autos-index' => 'App\\Http\\Livewire\\AutosIndex',
  'clientes-index' => 'App\\Http\\Livewire\\ClientesIndex',
  'modelos-index' => 'App\\Http\\Livewire\\ModelosIndex',
  'versiones-index' => 'App\\Http\\Livewire\\VersionesIndex',
);