<?php

namespace App\Http\Controllers;
use App\Models\Gasto;
use App\Models\Auto;


use Illuminate\Http\Request;

class GastoController extends Controller
{
    public function index (Auto $auto){

        $gastos = $auto->gastos();

        return $gastos;
    }
}
